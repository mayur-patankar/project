package com.bidding.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bidding.dto.BidProdDto;
import com.bidding.entity.Bidd;
import com.bidding.repository.BiddRepository;
import com.bidding.repository.BiddRepositoryImple;
import com.bidding.repository.CustomBidRepo;

@RestController
@CrossOrigin
public class BiddControllers {

	@Autowired
	CustomBidRepo cbr;
	
	@Autowired
	BiddRepository br;
	
	@PostMapping("/postBidd")
	public void postBid(@RequestBody Bidd b)
	{
		br.save(b);
	}
	
	@GetMapping("/getBidds")
	public List<Bidd> getBidds(@RequestBody BidProdDto bpd)
	{
		int id = bpd.getPro_id();
		List<Bidd> l = cbr.findBidds(id);
		return l;
	}
}
