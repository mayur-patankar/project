package com.bidding.dto;

public class BidProdDto {
	
	int pro_id;
	
	public int getPro_id() {
		return pro_id;
	}
	
	public void setPro_id(int pro_id) {
		this.pro_id = pro_id;
	}
}
