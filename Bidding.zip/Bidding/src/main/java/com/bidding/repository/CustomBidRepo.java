package com.bidding.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.bidding.entity.Bidd;
import com.bidding.entity.User;

@Repository
public class CustomBidRepo {
	
	@PersistenceContext
	EntityManager em;
	
	public List<Bidd> findBidds(int id)
	{
		return (List<Bidd>)
				em
				.createQuery("select b from Bidd b where b.pid = :m")
				.setParameter("m", id)
				.getResultList();
	}
}
