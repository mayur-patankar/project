package com.bidding.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bidding.entity.Bidd;

public interface BiddRepository extends JpaRepository<Bidd, Integer> {

}
