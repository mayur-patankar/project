package com.bidding.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "bidds")
public class Bidd {
	@Id
	@GeneratedValue
	int Id;
	int bidvalue;
	int pid;
	int uid;
	
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public int getBidvalue() {
		return bidvalue;
	}
	public void setBidvalue(int bidvalue) {
		this.bidvalue = bidvalue;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}
	
	
}
